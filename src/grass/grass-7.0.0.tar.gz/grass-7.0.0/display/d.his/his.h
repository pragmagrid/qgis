/* his.c */
void HIS_to_RGB(int, int, int, int, int, CELL *, CELL *, CELL *);
int make_gray_scale(struct Colors *);
