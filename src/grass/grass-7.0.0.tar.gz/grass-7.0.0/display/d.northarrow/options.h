
/* globals */
extern int fg_color;
extern int bg_color;
extern int do_background;

/* draw_n_arrow.c */
int draw_n_arrow(double, double, double, char *, double);
