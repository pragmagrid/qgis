int coor_path(struct Map_info *, const struct color_rgb *, int,
	      double, double, double, double);
