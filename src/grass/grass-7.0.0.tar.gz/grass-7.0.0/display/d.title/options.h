
extern const char *map_name;
extern const char *color;
extern float size;
extern int type;

#define NORMAL	1
#define FANCY	2
