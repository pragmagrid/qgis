/* where.c */
int where_am_i(char **, FILE *, int, int, int);
