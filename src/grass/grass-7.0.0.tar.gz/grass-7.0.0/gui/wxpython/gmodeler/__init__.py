all = [
    'preferences',
    'g.gui.gmodeler',
    'menudata',
    'model',
    'pystc',
    'dialogs',
    'toolbars',
    'frame',
    ]
