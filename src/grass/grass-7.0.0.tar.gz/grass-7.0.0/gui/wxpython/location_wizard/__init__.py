all = [
    'wizard',
    'base',
    'dialogs',
    ]
