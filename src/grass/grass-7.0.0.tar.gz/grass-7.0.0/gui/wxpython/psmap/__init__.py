all = [
    'g.gui.psmap',
    'menudata',
    'dialogs',
    'instructions',
    'toolbars',
    'utils',
    'frame',
    ]
